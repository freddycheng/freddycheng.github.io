<?php

  $about = array(
		'name' => 'Finnish',
		'author' => array(
			'name' => 'Leo Nikkilä',
			'email' => 'leo.nikkila@gmail.com',
			'website' => ''
		),
		'release-date' => '2013-06-23'
	);

	/**
	 * Select Box Link Field
	 */
	$dictionary = array(

		'Select Box Link' =>
		'Valintalaatikkolinkki',

		'Values' =>
		'Arvot',

		'Limit to %s entries' =>
		'Rajoita %s merkintään',

		'Allow selection of multiple options' =>
		'Salli useamman vaihtoehdon valitseminen',

	);
