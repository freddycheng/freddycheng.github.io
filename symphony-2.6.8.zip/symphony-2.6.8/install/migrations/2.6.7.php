<?php

    class migration_267 extends Migration
    {
        public static function getVersion()
        {
            return '2.6.7';
        }

        public static function getReleaseNotes()
        {
            return 'http://getsymphony.com/download/releases/version/2.6.7/';
        }
    }
