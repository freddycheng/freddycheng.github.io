<?php

	$about = array(
		'name' => 'Русский',
		'author' => array(
			'name' => 'Александр Бирюков',
			'email' => 'info@alexbirukov.ru',
			'website' => 'http://alexbirukov.ru'
		),
		'release-date' => '2013-10-04'
	);

	/**
	 * Select Box Link Field
	 */
	$dictionary = array(

		'Allow selection of multiple options' => 
		'Разрешить выбор нескольких опций.',

		'Limit to %s entries' => 
		'Лимит записей %s',

		'Select Box Link' => 
		'Ссылка на запись',

		'Values' => 
		'Значения',

		'Hide when prepopulated' => 
		'Скрывать при предварительном формировании',

	);
