<?php

	$about = array(
		'name' => 'Deutsch',
		'author' => array(
			'name' => 'Nils Hörrmann',
			'email' => 'post@nilshoerrmann.de',
			'website' => 'http://www.nilshoerrmann.de'
		),
		'release-date' => '2013-09-18'
	);

	/**
	 * Debug Devkit
	 */
	$dictionary = array(

		'Params' => 
		'Parameter',

		'Result' => 
		'Ergebnis',

		'XML' => 
		'XML',

		'Failed to create cache folder. Please check "%s" is writable.' => 
		'Cache-Ordner konnte nicht angelegt werden. Bitte überprüfen Sie, ob "%s" schreibbar ist.',

		'Cache folder is not writable. Please check permissions on "%s".' => 
		'Cache-Ordner ist nicht schreibbar. Bitte überprüfen Sie die Schreibrechte für "%s".',

		'Plain XML' => 
		'Reines XML',

	);
