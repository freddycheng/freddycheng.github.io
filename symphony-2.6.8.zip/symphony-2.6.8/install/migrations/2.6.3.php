<?php

    class migration_263 extends Migration
    {
        public static function getVersion()
        {
            return '2.6.3';
        }

        public static function getReleaseNotes()
        {
            return 'http://getsymphony.com/download/releases/version/2.6.3/';
        }
    }
