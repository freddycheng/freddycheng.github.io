<?php

	$about = array(
		'name' => 'Portuguese (Brazil)',
		'author' => array(
			'name' => 'Rainer Borene',
			'email' => 'me@rainerborene.com',
			'website' => 'http://rainerborene.com'
		),
		'release-date' => '2010-11-18'
	);
	
	
	/*
	 * EXTENSION: Debug Devkit
	 * Localisation strings
	 */

	$dictionary = array(

		'Debug' => 
		'Depurar',

		'Params' => 
		'Parâmetros',

		'XML' => 
		'XML',

		'Result' => 
		'Resultado'
		
	);
	