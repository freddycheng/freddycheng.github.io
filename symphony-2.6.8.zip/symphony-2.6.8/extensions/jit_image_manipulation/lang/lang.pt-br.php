<?php

	$about = array(
		'name' => 'Portuguese (Brazil)',
		'author' => array(
			'name' => 'Rainer Borene',
			'email' => 'me@rainerborene.com',
			'website' => 'http://rainerborene.com/'
		),
		'release-date' => '2009-10-08'
	);


	/*
	 * EXTENSION: JIT Image Manipulation
	 * Localisation strings
	 */

	$dictionary = array(

		'JIT Image Manipulation' => 
		'JIT Image Manipulation',

		'Trusted Sites' => 
		'Sites confiáveis',

		'Leave empty to disable external linking. Single rule per line. Add * at end for wild card matching.' => 
		'Deixe em branco para desabilitar links externos. Apenas uma regra por linha. Adicione o * no final para equivaler a um valor qualquer.'

	);
	